package com.dicoding.javafundamental.objek;
 
public class Hewan {
public void cetakNama(String nama) {
       System.out.println("Nama hewan: " + nama);
    }
}
