/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dicoding.javafundamental.objek;

/**
 *
 * @author jasti
 */
public class Main {
    

    public static void main(String[] args) {
       // menciptakan object dengan nama 'objekHewan'
       Hewan objekHewan = new Hewan();
       objekHewan.cetakNama("Elang");
    }
}
