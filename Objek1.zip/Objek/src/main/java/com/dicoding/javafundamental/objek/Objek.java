/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.dicoding.javafundamental.objek;

/**
 *
 * @author jasti
 */
public class Objek {
    public static void main(String[] args) {
       // menciptakan object dengan nama 'objekHewan'
       Hewan objekHewan = new Hewan();
       objekHewan.cetakNama("Elang");
    }
}
