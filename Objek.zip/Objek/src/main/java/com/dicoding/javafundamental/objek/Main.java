package com.dicoding.javafundamental.objek;

public class Main {
    public static void main(String[] args) {
       // menciptakan object dengan nama 'objekHewan'
       Hewan objekHewan = new Hewan();
       objekHewan.cetakNama("Elang");
    }
}
